// 商品详情页面
import React from 'react';

export default function page() {
  return <div>page</div>;
}
